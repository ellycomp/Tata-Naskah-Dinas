import React from 'react';
import { LetterDocument } from '../types/letter';
import { OfficialEmblem, OfficialStamp } from './OfficialEmblems';

interface LetterPreviewProps {
  doc: LetterDocument;
  zoom?: number;
  isExporting?: boolean;
}

export const PAPER_DIMENSIONS = {
  A4: { widthMm: 210, heightMm: 297 },
  F4: { widthMm: 215, heightMm: 330 },
} as const;

const MARGIN_MM = {
  standard: { top: 18, right: 20, bottom: 20, left: 24 },
  compact: { top: 14, right: 16, bottom: 16, left: 18 },
  wide: { top: 22, right: 25, bottom: 24, left: 28 },
} as const;

const FONT_FAMILIES = {
  times: '"Times New Roman", "Source Serif 4", Georgia, serif',
  arial: 'Arial, Helvetica, sans-serif',
  georgia: 'Georgia, "Source Serif 4", serif',
} as const;

export const LetterPreview: React.FC<LetterPreviewProps> = ({
  doc,
  zoom = 1,
  isExporting = false,
}) => {
  const { widthMm, heightMm } = PAPER_DIMENSIONS[doc.paperSize];
  const margins = MARGIN_MM[doc.marginPreset];
  const fontFamily = FONT_FAMILIES[doc.fontFamily];
  const kop = doc.letterhead;

  const leftSize = kop.leftLogoSize || 68;
  const rightSize = kop.rightLogoSize || 68;

  const renderLeftLogo = () => {
    if (kop.customLogoDataUrl) {
      return (
        <img
          src={kop.customLogoDataUrl}
          alt="Lambang Kiri"
          referrerPolicy="no-referrer"
          style={{
            width: `${leftSize}px`,
            height: `${leftSize}px`,
            objectFit: 'contain',
            display: 'block',
          }}
        />
      );
    }
    if (kop.builtInLogo !== 'none') {
      return <OfficialEmblem logoId={kop.builtInLogo} color={kop.accentColor} size={leftSize} />;
    }
    return null;
  };

  const renderRightLogo = () => {
    if (!kop.showRightLogo && kop.layout !== 'dual-center') return null;
    if (kop.rightLogoDataUrl) {
      return (
        <img
          src={kop.rightLogoDataUrl}
          alt="Lambang Kanan"
          referrerPolicy="no-referrer"
          style={{
            width: `${rightSize}px`,
            height: `${rightSize}px`,
            objectFit: 'contain',
            display: 'block',
          }}
        />
      );
    }
    const rightEmblem = kop.rightBuiltInLogo ?? kop.builtInLogo;
    if (rightEmblem && rightEmblem !== 'none') {
      return <OfficialEmblem logoId={rightEmblem} color={kop.accentColor} size={rightSize} />;
    }
    return null;
  };

  const leftLogoNode = renderLeftLogo();
  const rightLogoNode = renderRightLogo();
  const isLeftAligned = kop.layout === 'left-left';

  const renderDivider = () => {
    if (kop.dividerStyle === 'double-official') {
      return (
        <div style={{ marginTop: '8px', marginBottom: '16px' }}>
          <div style={{ height: '3px', backgroundColor: kop.accentColor || '#0f172a' }} />
          <div
            style={{
              height: '1px',
              backgroundColor: kop.accentColor || '#0f172a',
              marginTop: '2px',
            }}
          />
        </div>
      );
    }
    if (kop.dividerStyle === 'single-bold') {
      return (
        <div
          style={{
            marginTop: '8px',
            marginBottom: '16px',
            height: '2.5px',
            backgroundColor: kop.accentColor || '#0f172a',
          }}
        />
      );
    }
    return (
      <div
        style={{
          marginTop: '10px',
          marginBottom: '16px',
          height: '2px',
          backgroundColor: kop.accentColor || '#1e3a5f',
        }}
      />
    );
  };

  // Scale wrapper dimensions so layout occupies exact scaled box without whitespace gaps
  const pxPerMm = 3.7795275591;
  const sheetWidthPx = widthMm * pxPerMm;
  const sheetMinHeightPx = heightMm * pxPerMm;

  return (
    <div
      className="print-scale-wrapper"
      style={
        isExporting
          ? { width: `${widthMm}mm` }
          : {
              width: `${sheetWidthPx * zoom}px`,
              minHeight: `${sheetMinHeightPx * zoom}px`,
              position: 'relative',
            }
      }
    >
      <div
        id="printable-letter-sheet"
        style={{
          width: `${widthMm}mm`,
          minHeight: `${heightMm}mm`,
          paddingTop: `${margins.top}mm`,
          paddingRight: `${margins.right}mm`,
          paddingBottom: `${margins.bottom}mm`,
          paddingLeft: `${margins.left}mm`,
          backgroundColor: '#ffffff',
          color: '#111827',
          fontFamily,
          fontSize: `${doc.fontSizePt}pt`,
          lineHeight: 1.48,
          boxSizing: 'border-box',
          position: 'relative',
          transform: isExporting ? 'none' : `scale(${zoom})`,
          transformOrigin: 'top left',
          boxShadow: isExporting ? 'none' : '0 10px 30px rgba(15, 23, 42, 0.14)',
        }}
      >
        {/* Page-break visual guide for 1st page limit */}
        {!isExporting && (
          <div
            className="page-break-guide no-print"
            style={{
              position: 'absolute',
              top: `${heightMm}mm`,
              left: 0,
              right: 0,
              borderTop: '1px dashed #cbd5e1',
              pointerEvents: 'none',
            }}
          >
            <span
              style={{
                position: 'absolute',
                right: '8px',
                top: '-10px',
                backgroundColor: '#f8fafc',
                color: '#64748b',
                fontSize: '9px',
                fontFamily: 'Arial, sans-serif',
                padding: '1px 6px',
                border: '1px solid #e2e8f0',
                borderRadius: '3px',
              }}
            >
              Batas Halaman 1 ({doc.paperSize})
            </span>
          </div>
        )}

        {/* KOP SURAT RESMI */}
        <header style={{ width: '100%' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: isLeftAligned ? 'flex-start' : 'space-between',
              gap: '14px',
            }}
          >
            {leftLogoNode && (
              <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
                {leftLogoNode}
              </div>
            )}

            <div
              style={{
                flex: 1,
                textAlign: isLeftAligned ? 'left' : 'center',
              }}
            >
              {kop.parentOrg.trim() && (
                <div
                  style={{
                    fontSize: '10.5pt',
                    fontWeight: 600,
                    letterSpacing: '0.4px',
                    color: '#111827',
                    lineHeight: 1.25,
                    textTransform: 'uppercase',
                  }}
                >
                  {kop.parentOrg}
                </div>
              )}

              <div
                style={{
                  fontSize: '14.5pt',
                  fontWeight: 700,
                  letterSpacing: '0.3px',
                  color: kop.dividerStyle === 'accent-line' ? kop.accentColor : '#0f172a',
                  lineHeight: 1.2,
                  marginTop: kop.parentOrg.trim() ? '2px' : '0',
                  textTransform: 'uppercase',
                }}
              >
                {kop.orgName || 'NAMA INSTANSI / PERUSAHAAN'}
              </div>

              {kop.subUnit.trim() && (
                <div
                  style={{
                    fontSize: '10pt',
                    fontWeight: 600,
                    color: '#1f2937',
                    lineHeight: 1.25,
                    marginTop: '2px',
                  }}
                >
                  {kop.subUnit}
                </div>
              )}

              {kop.address.trim() && (
                <div
                  style={{
                    fontSize: '8.8pt',
                    color: '#374151',
                    lineHeight: 1.35,
                    marginTop: '3px',
                    whiteSpace: 'pre-line',
                  }}
                >
                  {kop.address}
                </div>
              )}

              {(() => {
                const mode =
                  kop.contactLastLineMode ||
                  (kop.websiteOnLastLine ? 'website-last' : 'inline');
                if (mode === 'website-last') {
                  return (
                    <>
                      {(kop.contactLine.trim() || kop.websiteEmailLine.trim()) && (
                        <div
                          style={{
                            fontSize: '8.5pt',
                            color: '#374151',
                            lineHeight: 1.35,
                          }}
                        >
                          {[kop.contactLine, kop.websiteEmailLine]
                            .map((s) => s.trim())
                            .filter(Boolean)
                            .join(' · ')}
                        </div>
                      )}
                      {kop.websiteLine && kop.websiteLine.trim() && (
                        <div
                          style={{
                            fontSize: '8.5pt',
                            color: '#374151',
                            lineHeight: 1.35,
                          }}
                        >
                          {kop.websiteLine.trim()}
                        </div>
                      )}
                    </>
                  );
                }
                if (mode === 'email-last') {
                  return (
                    <>
                      {(kop.contactLine.trim() ||
                        (kop.websiteLine && kop.websiteLine.trim())) && (
                        <div
                          style={{
                            fontSize: '8.5pt',
                            color: '#374151',
                            lineHeight: 1.35,
                          }}
                        >
                          {[kop.contactLine, kop.websiteLine || '']
                            .map((s) => s.trim())
                            .filter(Boolean)
                            .join(' · ')}
                        </div>
                      )}
                      {kop.websiteEmailLine.trim() && (
                        <div
                          style={{
                            fontSize: '8.5pt',
                            color: '#374151',
                            lineHeight: 1.35,
                          }}
                        >
                          {kop.websiteEmailLine.trim()}
                        </div>
                      )}
                    </>
                  );
                }
                return (
                  (kop.contactLine.trim() ||
                    (kop.websiteLine && kop.websiteLine.trim()) ||
                    kop.websiteEmailLine.trim()) && (
                    <div
                      style={{
                        fontSize: '8.5pt',
                        color: '#374151',
                        lineHeight: 1.35,
                      }}
                    >
                      {[kop.contactLine, kop.websiteLine || '', kop.websiteEmailLine]
                        .map((s) => s.trim())
                        .filter(Boolean)
                        .join(' · ')}
                    </div>
                  )
                );
              })()}
            </div>

            {!isLeftAligned && (
              <div
                style={{
                  flexShrink: 0,
                  width: rightLogoNode ? 'auto' : leftLogoNode ? `${leftSize}px` : '0px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                }}
              >
                {rightLogoNode}
              </div>
            )}
          </div>
          {renderDivider()}
        </header>

        {/* BAGIAN PEMBUKA KEPALA SURAT */}
        {doc.formatStyle === 'correspondence' ? (
          <>
            {/* Tempat & Tanggal di kanan atas */}
            <div style={{ textAlign: 'right', marginBottom: '10px' }}>
              <span>
                {doc.city}
                {doc.city && doc.dateString ? ', ' : ''}
                {doc.dateString}
              </span>
            </div>

            {/* Metadata Nomor, Lampiran, Sifat, Hal */}
            <table
              style={{
                width: '100%',
                borderCollapse: 'collapse',
                marginBottom: '14px',
              }}
            >
              <tbody>
                <tr>
                  <td style={{ width: '82px', verticalAlign: 'top', padding: '1px 0' }}>Nomor</td>
                  <td style={{ width: '14px', verticalAlign: 'top', padding: '1px 0' }}>:</td>
                  <td style={{ verticalAlign: 'top', padding: '1px 0', whiteSpace: 'pre-wrap' }}>
                    {doc.letterNumber || '-'}
                  </td>
                </tr>
                {doc.urgency && doc.urgency !== '-' && (
                  <tr>
                    <td style={{ verticalAlign: 'top', padding: '1px 0' }}>Sifat</td>
                    <td style={{ verticalAlign: 'top', padding: '1px 0' }}>:</td>
                    <td style={{ verticalAlign: 'top', padding: '1px 0' }}>{doc.urgency}</td>
                  </tr>
                )}
                <tr>
                  <td style={{ verticalAlign: 'top', padding: '1px 0' }}>Lampiran</td>
                  <td style={{ verticalAlign: 'top', padding: '1px 0' }}>:</td>
                  <td style={{ verticalAlign: 'top', padding: '1px 0' }}>{doc.attachment || '-'}</td>
                </tr>
                <tr>
                  <td style={{ verticalAlign: 'top', padding: '1px 0' }}>Hal</td>
                  <td style={{ verticalAlign: 'top', padding: '1px 0' }}>:</td>
                  <td style={{ verticalAlign: 'top', padding: '1px 0', fontWeight: 700 }}>
                    {doc.subject}
                  </td>
                </tr>
              </tbody>
            </table>

            {/* Tujuan Surat */}
            {doc.recipientLines.some((l) => l.trim().length > 0) && (
              <div style={{ marginBottom: '14px' }}>
                {doc.recipientLines.map((line, idx) => (
                  <div key={idx} style={{ minHeight: '1em' }}>
                    {line}
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          /* Format Decree: Judul Terpusat + Nomor di bawah judul */
          <div style={{ textAlign: 'center', marginTop: '6px', marginBottom: '18px' }}>
            <div
              style={{
                fontSize: `${doc.fontSizePt + 2}pt`,
                fontWeight: 700,
                textDecoration: 'underline',
                textUnderlineOffset: '3px',
                letterSpacing: '0.5px',
                textTransform: 'uppercase',
              }}
            >
              {doc.decreeTitle || 'SURAT RESMI'}
            </div>
            <div style={{ marginTop: '3px', fontWeight: 600, whiteSpace: 'pre-wrap' }}>
              Nomor: {doc.letterNumber || '-'}
            </div>
          </div>
        )}

        {/* SALAM PEMBUKA */}
        {doc.salutation.trim() && (
          <div style={{ marginBottom: '10px' }}>{doc.salutation}</div>
        )}

        {/* PARAGRAF PEMBUKA */}
        {doc.openingParagraph.trim() && (
          <p
            style={{
              margin: '0 0 12px 0',
              textAlign: 'justify',
              whiteSpace: 'pre-line',
            }}
          >
            {doc.openingParagraph}
          </p>
        )}

        {/* BLOK RINCIAN TERSTRUKTUR */}
        {doc.detailRows.length > 0 && (
          <table
            style={{
              width: 'calc(100% - 20px)',
              borderCollapse: 'collapse',
              margin: '6px 0 14px 20px',
            }}
          >
            <tbody>
              {doc.detailRows.map((row) => (
                <tr key={row.id}>
                  <td
                    style={{
                      width: '165px',
                      verticalAlign: 'top',
                      padding: '2.5px 6px 2.5px 0',
                    }}
                  >
                    {row.label}
                  </td>
                  <td style={{ width: '14px', verticalAlign: 'top', padding: '2.5px 0' }}>:</td>
                  <td
                    style={{
                      verticalAlign: 'top',
                      padding: '2.5px 0',
                      fontWeight: 500,
                      whiteSpace: 'pre-line',
                    }}
                  >
                    {row.value}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* PARAGRAF ISI */}
        {doc.bodyParagraphs.map(
          (para, index) =>
            para.trim() && (
              <p
                key={index}
                style={{
                  margin: '0 0 11px 0',
                  textAlign: 'justify',
                  whiteSpace: 'pre-line',
                }}
              >
                {para}
              </p>
            )
        )}

        {/* PARAGRAF PENUTUP */}
        {doc.closingParagraph.trim() && (
          <p
            style={{
              margin: '0 0 22px 0',
              textAlign: 'justify',
              whiteSpace: 'pre-line',
            }}
          >
            {doc.closingParagraph}
          </p>
        )}

        {/* BLOK PENGESAHAN & TANDA TANGAN */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'flex-end',
            marginTop: '12px',
            pageBreakInside: 'avoid',
          }}
        >
          <div
            style={{
              width: '260px',
              position: 'relative',
              textAlign: 'left',
            }}
          >
            {/* Untuk surat format decree, tampilkan kota & tanggal di atas jabatan penandatangan */}
            {doc.formatStyle === 'decree' && (doc.city || doc.dateString) && (
              <div style={{ marginBottom: '2px' }}>
                {doc.city}
                {doc.city && doc.dateString ? ', ' : ''}
                {doc.dateString}
              </div>
            )}

            {doc.signerDepartment.trim() && (
              <div style={{ whiteSpace: 'pre-line', lineHeight: 1.35 }}>
                {doc.signerDepartment}
              </div>
            )}

            {doc.signerTitle.trim() && (
              <div style={{ whiteSpace: 'pre-line', lineHeight: 1.35 }}>
                {doc.signerTitle}
              </div>
            )}

            {/* Area Tanda Tangan & Stempel */}
            <div
              style={{
                height: '82px',
                position: 'relative',
                display: 'flex',
                alignItems: 'center',
              }}
            >
              {doc.showStamp && (
                <div
                  style={{
                    position: 'absolute',
                    left: '-48px',
                    top: '-22px',
                    pointerEvents: 'none',
                    zIndex: 1,
                  }}
                >
                  <OfficialStamp
                    topText={doc.stampTextTop || kop.orgName}
                    centerText={doc.stampTextCenter || doc.city || 'RESMI'}
                    color={doc.stampColor || '#1e3a8a'}
                  />
                </div>
              )}

              {doc.signatureDataUrl && (
                <img
                  src={doc.signatureDataUrl}
                  alt="Tanda Tangan"
                  referrerPolicy="no-referrer"
                  style={{
                    maxHeight: `${Math.round(68 * (doc.signatureScale / 100))}px`,
                    maxWidth: '190px',
                    objectFit: 'contain',
                    position: 'relative',
                    zIndex: 2,
                    marginLeft: '10px',
                  }}
                />
              )}
            </div>

            <div
              style={{
                fontWeight: 700,
                textDecoration: 'underline',
                textUnderlineOffset: '2px',
                position: 'relative',
                zIndex: 2,
              }}
            >
              {doc.signerName || 'Nama Pejabat Penandatangan'}
            </div>

            {doc.signerIdValue.trim() && (
              <div style={{ fontSize: `${Math.max(doc.fontSizePt - 1, 9)}pt` }}>
                {doc.signerIdLabel ? `${doc.signerIdLabel}. ` : ''}
                {doc.signerIdValue}
              </div>
            )}
          </div>
        </div>

        {/* TEMBUSAN */}
        {doc.ccList.some((c) => c.trim().length > 0) && (
          <div
            style={{
              marginTop: '24px',
              fontSize: `${Math.max(doc.fontSizePt - 1, 9)}pt`,
              pageBreakInside: 'avoid',
            }}
          >
            <div style={{ fontWeight: 600, textDecoration: 'underline', marginBottom: '2px' }}>
              Tembusan:
            </div>
            <ol style={{ margin: 0, paddingLeft: '18px' }}>
              {doc.ccList
                .filter((c) => c.trim().length > 0)
                .map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
            </ol>
          </div>
        )}
      </div>
    </div>
  );
};
