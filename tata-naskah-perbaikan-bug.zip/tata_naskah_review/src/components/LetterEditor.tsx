import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Upload,
  RefreshCw,
  Calendar,
  BookmarkPlus,
  Building2,
  FileText,
  AlignLeft,
  PenTool,
} from 'lucide-react';
import {
  BuiltInLogoId,
  ContactLastLineMode,
  DividerStyle,
  LetterDocument,
  LetterFont,
  LetterheadConfig,
  LetterheadLayout,
  MarginPreset,
  PaperSize,
} from '../types/letter';
import {
  LETTER_SUBJECT_CODES,
  INSTITUTION_CODES,
  formatIndonesianDate,
  formatOfficialLetterNumber,
  generateLetterNumber,
  getInstitutionCodeFromKop,
  getRomanMonthAndYearFromDateString,
  parseOfficialLetterNumber,
} from '../data/presets';
import { SignaturePad } from './SignaturePad';

export type EditorTab = 'kop' | 'kepala' | 'isi' | 'pengesahan';

interface LetterEditorProps {
  doc: LetterDocument;
  onChange: (updated: LetterDocument) => void;
  letterheadProfiles: LetterheadConfig[];
  onSaveLetterheadProfile: (profile: LetterheadConfig) => void;
}

const ACCENT_SWATCHES = [
  { label: 'Hitam Resmi', value: '#0f172a' },
  { label: 'Biru Instansi', value: '#1e3a5f' },
  { label: 'Hijau Kementerian', value: '#14532d' },
  { label: 'Merah Marun', value: '#7c2d12' },
];

export const LetterEditor: React.FC<LetterEditorProps> = ({
  doc,
  onChange,
  letterheadProfiles,
  onSaveLetterheadProfile,
}) => {
  const [activeTab, setActiveTab] = useState<EditorTab>('kop');
  const [savedNotice, setSavedNotice] = useState(false);

  const updateDoc = (patch: Partial<LetterDocument>) => {
    onChange({
      ...doc,
      ...patch,
      updatedAt: new Date().toISOString(),
    });
  };

  const updateKop = (patch: Partial<LetterheadConfig>) => {
    updateDoc({
      letterhead: {
        ...doc.letterhead,
        ...patch,
      },
    });
  };

  const handleUploadLogo = (
    e: React.ChangeEvent<HTMLInputElement>,
    target: 'left' | 'right'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        if (target === 'left') {
          updateKop({ customLogoDataUrl: reader.result });
        } else {
          updateKop({ rightLogoDataUrl: reader.result, showRightLogo: true });
        }
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSaveCurrentKop = () => {
    const profileToSave: LetterheadConfig = {
      ...doc.letterhead,
      id: `kop-custom-${Date.now()}`,
      profileName: doc.letterhead.orgName || 'Kop Surat Kustom',
    };
    onSaveLetterheadProfile(profileToSave);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2200);
  };

  const getDefaultSubjectCode = () => {
    const prefixMap: Record<string, string> = {
      'undangan-rapat': 'UND',
      'surat-tugas': 'ST',
      'surat-edaran': 'SE',
      'surat-keterangan-instansi': 'SUKET',
      'keterangan-aktif-sekolah': 'SUKET',
      'penawaran-kerjasama': 'SPMH',
      'keterangan-kerja': 'SUKET',
      'surat-peringatan': 'SP',
      'permohonan-izin-kegiatan': 'SPMH',
      'permohonan-rekomendasi': 'SPMH',
    };
    return prefixMap[doc.templateId] || 'UND';
  };

  const parsedNumber = parseOfficialLetterNumber(
    doc.letterNumber,
    doc.letterhead,
    doc.dateString
  );

  const updateNumberParts = (patch: Partial<typeof parsedNumber>) => {
    const nextParts = { ...parsedNumber, ...patch };
    updateDoc({ letterNumber: formatOfficialLetterNumber(nextParts) });
  };

  const handleAutoNumber = () => {
    const orgCode = getInstitutionCodeFromKop(doc.letterhead);
    const subjectCode = parsedNumber.subjectCode || getDefaultSubjectCode();
    updateDoc({
      letterNumber: generateLetterNumber(
        subjectCode,
        orgCode,
        parsedNumber.scope,
        '',
        doc.dateString
      ),
    });
  };

  const addDetailRow = () => {
    updateDoc({
      detailRows: [
        ...doc.detailRows,
        { id: `row-${Date.now()}`, label: 'Keterangan', value: '' },
      ],
    });
  };

  const updateDetailRow = (id: string, field: 'label' | 'value', val: string) => {
    updateDoc({
      detailRows: doc.detailRows.map((r) => (r.id === id ? { ...r, [field]: val } : r)),
    });
  };

  const removeDetailRow = (id: string) => {
    updateDoc({
      detailRows: doc.detailRows.filter((r) => r.id !== id),
    });
  };

  const addBodyParagraph = () => {
    updateDoc({
      bodyParagraphs: [...doc.bodyParagraphs, ''],
    });
  };

  const updateBodyParagraph = (idx: number, val: string) => {
    const next = [...doc.bodyParagraphs];
    next[idx] = val;
    updateDoc({ bodyParagraphs: next });
  };

  const removeBodyParagraph = (idx: number) => {
    updateDoc({
      bodyParagraphs: doc.bodyParagraphs.filter((_, i) => i !== idx),
    });
  };

  const tabs: { id: EditorTab; label: string; icon: React.ReactNode }[] = [
    { id: 'kop', label: 'Kop Surat', icon: <Building2 className="w-3.5 h-3.5" /> },
    { id: 'kepala', label: 'Nomor & Tujuan', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'isi', label: 'Isi Naskah', icon: <AlignLeft className="w-3.5 h-3.5" /> },
    { id: 'pengesahan', label: 'TTD & Kertas', icon: <PenTool className="w-3.5 h-3.5" /> },
  ];

  const inputClass =
    'w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-[#1e3a5f] focus:outline-none focus:ring-1 focus:ring-[#1e3a5f] transition-colors';
  const labelClass = 'block text-xs font-medium text-slate-700 mb-1';

  return (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Editor Tab Navigation */}
      <div className="flex items-center border-b border-slate-200 bg-slate-50/70 px-3 pt-2 gap-1 overflow-x-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isActive
                  ? 'border-[#1e3a5f] text-[#1e3a5f] bg-white rounded-t-md'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Editor Body */}
      <div className="flex-1 overflow-y-auto workspace-scroll p-5 space-y-5">
        {activeTab === 'kop' && (
          <>
            {/* Preset Selector */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-700">
                  Pilih Profil Kop Surat Tersimpan
                </label>
                <button
                  type="button"
                  onClick={handleSaveCurrentKop}
                  className="inline-flex items-center gap-1 text-xs font-medium text-[#1e3a5f] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <BookmarkPlus className="w-3.5 h-3.5" />
                  {savedNotice ? 'Tersimpan ke Profil' : 'Simpan Profil Kop Ini'}
                </button>
              </div>
              <select
                value={
                  letterheadProfiles.some((p) => p.id === doc.letterhead.id)
                    ? doc.letterhead.id
                    : ''
                }
                onChange={(e) => {
                  const found = letterheadProfiles.find((p) => p.id === e.target.value);
                  if (found) {
                    const nextOrgCode = getInstitutionCodeFromKop(found);
                    const nextLetterNumber = formatOfficialLetterNumber({
                      ...parsedNumber,
                      orgCode: nextOrgCode,
                    });
                    updateDoc({
                      letterhead: { ...found },
                      stampTextTop: found.orgName,
                      letterNumber: nextLetterNumber,
                    });
                  }
                }}
                className={inputClass}
              >
                <option value="" disabled>
                  -- Pilih profil kop surat atau sunting manual di bawah --
                </option>
                {letterheadProfiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.profileName} ({p.category})
                  </option>
                ))}
              </select>
            </div>

            <div className="border-t border-slate-100 pt-4 space-y-3.5">
              <div>
                <label className={labelClass}>Instansi Induk / Kementerian (Opsional)</label>
                <input
                  type="text"
                  value={doc.letterhead.parentOrg}
                  onChange={(e) => updateKop({ parentOrg: e.target.value })}
                  placeholder="Contoh: PEMERINTAH PROVINSI DKI JAKARTA"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Nama Instansi / Perusahaan / Lembaga</label>
                <input
                  type="text"
                  value={doc.letterhead.orgName}
                  onChange={(e) => updateKop({ orgName: e.target.value })}
                  placeholder="Contoh: PT NUSANTARA KARYA MANDIRI"
                  className={inputClass}
                />
              </div>

              {doc.letterhead.id === 'kop-sdit-qudwah' ||
              doc.letterhead.id === 'kop-kbit-qudwah' ||
              /^NPSN:/i.test(doc.letterhead.subUnit.trim()) ? (
                (() => {
                  const match = doc.letterhead.subUnit.match(
                    /^NPSN:\s*(.*?)\s*\|\s*Akreditasi:\s*(.*)$/i
                  );
                  const npsnVal = match ? match[1] : '';
                  const akredVal = match ? match[2] : '';
                  const updateNpsnAkred = (nextNpsn: string, nextAkred: string) => {
                    updateKop({
                      subUnit: `NPSN: ${nextNpsn} | Akreditasi: ${nextAkred}`,
                    });
                  };
                  return (
                    <div>
                      <label className={labelClass}>NPSN &amp; Akreditasi</label>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 flex items-center rounded-md border border-slate-200 bg-white overflow-hidden focus-within:border-[#1e3a5f] focus-within:ring-1 focus-within:ring-[#1e3a5f]">
                          <span className="px-2.5 py-2 text-xs font-medium text-slate-600 bg-slate-50 border-r border-slate-200 whitespace-nowrap">
                            NPSN:
                          </span>
                          <input
                            type="text"
                            value={npsnVal}
                            onChange={(e) => updateNpsnAkred(e.target.value, akredVal)}
                            placeholder="Contoh: 69900000"
                            className="w-full px-2.5 py-2 text-sm text-slate-900 font-mono tabular-nums focus:outline-none"
                          />
                        </div>
                        <span className="text-sm font-semibold text-slate-400 select-none">
                          |
                        </span>
                        <div className="flex-1 flex items-center rounded-md border border-slate-200 bg-white overflow-hidden focus-within:border-[#1e3a5f] focus-within:ring-1 focus-within:ring-[#1e3a5f]">
                          <span className="px-2.5 py-2 text-xs font-medium text-slate-600 bg-slate-50 border-r border-slate-200 whitespace-nowrap">
                            Akreditasi:
                          </span>
                          <input
                            type="text"
                            value={akredVal}
                            onChange={(e) => updateNpsnAkred(npsnVal, e.target.value)}
                            placeholder="Contoh: B"
                            className="w-full px-2.5 py-2 text-sm text-slate-900 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div>
                  <label className={labelClass}>Sub Unit / Fakultas / Divisi (Opsional)</label>
                  <input
                    type="text"
                    value={doc.letterhead.subUnit}
                    onChange={(e) => updateKop({ subUnit: e.target.value })}
                    placeholder="Contoh: DIVISI OPERASIONAL & SUMBER DAYA MANUSIA"
                    className={inputClass}
                  />
                </div>
              )}

              <div>
                <label className={labelClass}>Alamat Lengkap (Tekan Enter untuk baris ke-2)</label>
                <textarea
                  rows={2}
                  value={doc.letterhead.address}
                  onChange={(e) => updateKop({ address: e.target.value })}
                  placeholder="Baris 1: Jalan, Desa, Kecamatan&#10;Baris 2: Kab. ..., Provinsi"
                  className={inputClass}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className={labelClass}>Telepon / WhatsApp</label>
                  <input
                    type="text"
                    value={doc.letterhead.contactLine}
                    onChange={(e) => updateKop({ contactLine: e.target.value })}
                    placeholder="Telp. 0813-xxxx-xxxx"
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>Website</label>
                  <input
                    type="text"
                    value={doc.letterhead.websiteLine || ''}
                    onChange={(e) => updateKop({ websiteLine: e.target.value })}
                    placeholder="Website: www.domain.sch.id"
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>Email Resmi</label>
                  <input
                    type="text"
                    value={doc.letterhead.websiteEmailLine}
                    onChange={(e) => updateKop({ websiteEmailLine: e.target.value })}
                    placeholder="Email: info@domain.sch.id"
                    className={inputClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Susunan Baris Kontak &amp; Tautan</label>
                <select
                  value={
                    doc.letterhead.contactLastLineMode ||
                    (doc.letterhead.websiteOnLastLine ? 'website-last' : 'inline')
                  }
                  onChange={(e) => {
                    const mode = e.target.value as ContactLastLineMode;
                    updateKop({
                      contactLastLineMode: mode,
                      websiteOnLastLine: mode === 'website-last',
                    });
                  }}
                  className={inputClass}
                >
                  <option value="email-last">Email di baris terakhir (Telepon · Website / Email)</option>
                  <option value="website-last">Website di baris terakhir (Telepon · Email / Website)</option>
                  <option value="inline">Sejajar dalam 1 baris (Telepon · Website · Email)</option>
                </select>
              </div>
            </div>

            {/* Dua Tempat Unggah Lambang & Pengaturan Ukuran */}
            <div className="border-t border-slate-100 pt-4 space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-800">
                  Lambang Kop Surat (Kiri &amp; Kanan)
                </label>
                <button
                  type="button"
                  onClick={() =>
                    updateKop({
                      rightLogoSize: doc.letterhead.leftLogoSize || 68,
                    })
                  }
                  className="text-xs font-medium text-[#1e3a5f] hover:underline cursor-pointer"
                >
                  Samakan Ukuran
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Slot Lambang Kiri */}
                <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-800">
                      1. Lambang Kiri
                    </span>
                    <span className="text-xs font-mono tabular-nums text-slate-600">
                      {doc.letterhead.leftLogoSize || 68}px
                    </span>
                  </div>

                  <select
                    value={doc.letterhead.builtInLogo}
                    onChange={(e) =>
                      updateKop({
                        builtInLogo: e.target.value as BuiltInLogoId,
                        customLogoDataUrl: null,
                      })
                    }
                    className="w-full rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#1e3a5f] focus:outline-none"
                  >
                    <option value="organization">Lambang Yayasan / Organisasi</option>
                    <option value="academic">Lambang Pendidikan / Sekolah</option>
                    <option value="shield">Lambang Perisai Resmi</option>
                    <option value="corporate">Monogram Lembaga</option>
                    <option value="none">Tanpa Lambang</option>
                  </select>

                  <div className="flex items-center gap-2">
                    <label className="flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md cursor-pointer whitespace-nowrap">
                      <Upload className="w-3.5 h-3.5" />
                      {doc.letterhead.customLogoDataUrl ? 'Ganti Lambang' : 'Unggah Lambang'}
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/svg+xml,image/webp"
                        onChange={(e) => handleUploadLogo(e, 'left')}
                        className="hidden"
                      />
                    </label>
                    {doc.letterhead.customLogoDataUrl && (
                      <button
                        type="button"
                        onClick={() => updateKop({ customLogoDataUrl: null })}
                        title="Hapus gambar unggahan"
                        className="p-1.5 text-red-600 bg-white border border-slate-200 hover:bg-red-50 rounded-md cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                      <span>Ukuran Lambang Kiri</span>
                      <span className="font-mono tabular-nums">36–110 px</span>
                    </div>
                    <input
                      type="range"
                      min={36}
                      max={110}
                      value={doc.letterhead.leftLogoSize || 68}
                      onChange={(e) =>
                        updateKop({ leftLogoSize: Number(e.target.value) })
                      }
                      className="w-full accent-[#1e3a5f] cursor-pointer"
                    />
                  </div>
                </div>

                {/* Slot Lambang Kanan */}
                <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-800">
                      2. Lambang Kanan
                    </span>
                    <span className="text-xs font-mono tabular-nums text-slate-600">
                      {doc.letterhead.rightLogoSize || 68}px
                    </span>
                  </div>

                  <select
                    value={doc.letterhead.rightBuiltInLogo ?? doc.letterhead.builtInLogo}
                    onChange={(e) =>
                      updateKop({
                        rightBuiltInLogo: e.target.value as BuiltInLogoId,
                        rightLogoDataUrl: null,
                        showRightLogo: e.target.value !== 'none',
                      })
                    }
                    className="w-full rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#1e3a5f] focus:outline-none"
                  >
                    <option value="organization">Lambang Yayasan / Organisasi</option>
                    <option value="academic">Lambang Pendidikan / Sekolah</option>
                    <option value="shield">Lambang Perisai Resmi</option>
                    <option value="corporate">Monogram Lembaga</option>
                    <option value="none">Tanpa Lambang</option>
                  </select>

                  <div className="flex items-center gap-2">
                    <label className="flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md cursor-pointer whitespace-nowrap">
                      <Upload className="w-3.5 h-3.5" />
                      {doc.letterhead.rightLogoDataUrl ? 'Ganti Lambang' : 'Unggah Lambang'}
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/svg+xml,image/webp"
                        onChange={(e) => handleUploadLogo(e, 'right')}
                        className="hidden"
                      />
                    </label>
                    {doc.letterhead.rightLogoDataUrl && (
                      <button
                        type="button"
                        onClick={() => updateKop({ rightLogoDataUrl: null })}
                        title="Hapus gambar unggahan"
                        className="p-1.5 text-red-600 bg-white border border-slate-200 hover:bg-red-50 rounded-md cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                      <span>Ukuran Lambang Kanan</span>
                      <span className="font-mono tabular-nums">36–110 px</span>
                    </div>
                    <input
                      type="range"
                      min={36}
                      max={110}
                      value={doc.letterhead.rightLogoSize || 68}
                      onChange={(e) =>
                        updateKop({ rightLogoSize: Number(e.target.value) })
                      }
                      className="w-full accent-[#1e3a5f] cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Tata Letak Kop</label>
                  <select
                    value={doc.letterhead.layout}
                    onChange={(e) => {
                      const layout = e.target.value as LetterheadLayout;
                      updateKop({
                        layout,
                        showRightLogo: layout === 'dual-center',
                      });
                    }}
                    className={inputClass}
                  >
                    <option value="dual-center">Dua Lambang (Kiri &amp; Kanan) · Teks Tengah</option>
                    <option value="left-center">Lambang Kiri · Teks Tengah</option>
                    <option value="left-left">Lambang Kiri · Teks Kiri</option>
                  </select>
                </div>

                <div>
                  <label className={labelClass}>Garis Pembatas Kop</label>
                  <select
                    value={doc.letterhead.dividerStyle}
                    onChange={(e) =>
                      updateKop({ dividerStyle: e.target.value as DividerStyle })
                    }
                    className={inputClass}
                  >
                    <option value="double-official">Garis Ganda Tebal-Tipis (Resmi)</option>
                    <option value="single-bold">Garis Tunggal Tegas</option>
                    <option value="accent-line">Garis Aksen Berwarna</option>
                  </select>
                </div>
              </div>

              <div>
                <label className={labelClass}>Warna Aksen Kop &amp; Garis</label>
                <div className="flex items-center gap-2.5">
                  {ACCENT_SWATCHES.map((swatch) => {
                    const active = doc.letterhead.accentColor === swatch.value;
                    return (
                      <button
                        key={swatch.value}
                        type="button"
                        onClick={() => updateKop({ accentColor: swatch.value })}
                        title={swatch.label}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-md border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                          active
                            ? 'border-slate-900 bg-slate-100 font-medium text-slate-900'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span
                          className="w-3 h-3 rounded-sm inline-block shrink-0"
                          style={{ backgroundColor: swatch.value }}
                        />
                        {swatch.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'kepala' && (
          <>
            <div>
              <label className={labelClass}>Struktur Kepala Surat</label>
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => updateDoc({ formatStyle: 'correspondence' })}
                  className={`py-2 px-3 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    doc.formatStyle === 'correspondence'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Korespondensi (Hal &amp; Yth.)
                </button>
                <button
                  type="button"
                  onClick={() => updateDoc({ formatStyle: 'decree' })}
                  className={`py-2 px-3 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    doc.formatStyle === 'decree'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Judul Tengah (Tugas/Ket.)
                </button>
              </div>
            </div>

            {doc.formatStyle === 'decree' && (
              <div>
                <label className={labelClass}>Judul Surat (Tengah Atas)</label>
                <input
                  type="text"
                  value={doc.decreeTitle}
                  onChange={(e) => updateDoc({ decreeTitle: e.target.value })}
                  placeholder="Contoh: SURAT KETERANGAN / SURAT PERINTAH TUGAS"
                  className={inputClass}
                />
              </div>
            )}

            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-800">
                  Pengaturan Nomor Surat Resmi
                </label>
                <button
                  type="button"
                  onClick={handleAutoNumber}
                  className="inline-flex items-center gap-1 text-xs font-medium text-[#1e3a5f] hover:underline cursor-pointer whitespace-nowrap shrink-0"
                >
                  <RefreshCw className="w-3 h-3" />
                  Kosongkan &amp; Sesuaikan
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className={labelClass}>No. Urut (Opsional / Kosongkan)</label>
                  <input
                    type="text"
                    value={parsedNumber.seq}
                    onChange={(e) => updateNumberParts({ seq: e.target.value })}
                    placeholder="Dikosongkan (mis. 001)"
                    className={`${inputClass} font-mono tabular-nums`}
                  />
                </div>

                <div>
                  <label className={labelClass}>Tujuan Surat (A / B)</label>
                  <select
                    value={parsedNumber.scope}
                    onChange={(e) =>
                      updateNumberParts({ scope: e.target.value as 'A' | 'B' })
                    }
                    className={inputClass}
                  >
                    <option value="A">A · Surat Internal</option>
                    <option value="B">B · Surat Eksternal</option>
                  </select>
                </div>

                <div>
                  <label className={labelClass}>Kode Perihal Surat</label>
                  <select
                    value={parsedNumber.subjectCode}
                    onChange={(e) => updateNumberParts({ subjectCode: e.target.value })}
                    className={inputClass}
                  >
                    {LETTER_SUBJECT_CODES.map((item) => (
                      <option key={item.code} value={item.code}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className={labelClass}>Kode Lembaga Penerbit</label>
                  <select
                    value={parsedNumber.orgCode}
                    onChange={(e) => updateNumberParts({ orgCode: e.target.value })}
                    className={inputClass}
                  >
                    {INSTITUTION_CODES.map((item) => (
                      <option key={item.code} value={item.code}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className={labelClass}>Hasil Nomor Surat (Dapat Diedit Manual)</label>
                <input
                  type="text"
                  value={doc.letterNumber}
                  onChange={(e) => updateDoc({ letterNumber: e.target.value })}
                  placeholder="    .A/UND-SDITQ/XI/2026"
                  className={`${inputClass} font-mono tabular-nums`}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className={labelClass}>Kota Penerbitan</label>
                <input
                  type="text"
                  value={doc.city}
                  onChange={(e) => updateDoc({ city: e.target.value })}
                  placeholder="Jakarta"
                  className={inputClass}
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-slate-700">Tanggal Surat</label>
                  <button
                    type="button"
                    onClick={() => {
                      const nextDate = formatIndonesianDate();
                      const { romanMonth, year } =
                        getRomanMonthAndYearFromDateString(nextDate);
                      updateDoc({
                        dateString: nextDate,
                        letterNumber: formatOfficialLetterNumber({
                          ...parsedNumber,
                          romanMonth,
                          year,
                        }),
                      });
                    }}
                    className="inline-flex items-center gap-1 text-xs font-medium text-[#1e3a5f] hover:underline cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <Calendar className="w-3 h-3" />
                    Hari Ini
                  </button>
                </div>
                <input
                  type="text"
                  value={doc.dateString}
                  onChange={(e) => {
                    const nextDate = e.target.value;
                    const { romanMonth, year } =
                      getRomanMonthAndYearFromDateString(nextDate);
                    updateDoc({
                      dateString: nextDate,
                      letterNumber: formatOfficialLetterNumber({
                        ...parsedNumber,
                        romanMonth,
                        year,
                      }),
                    });
                  }}
                  placeholder="14 November 2026"
                  className={inputClass}
                />
              </div>
            </div>

            {doc.formatStyle === 'correspondence' && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className={labelClass}>Sifat Surat</label>
                    <select
                      value={doc.urgency}
                      onChange={(e) => updateDoc({ urgency: e.target.value })}
                      className={inputClass}
                    >
                      <option value="-">Tidak Dicantumkan</option>
                      <option value="Biasa">Biasa</option>
                      <option value="Penting">Penting</option>
                      <option value="Segera">Segera</option>
                      <option value="Rahasia">Rahasia</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelClass}>Lampiran</label>
                    <input
                      type="text"
                      value={doc.attachment}
                      onChange={(e) => updateDoc({ attachment: e.target.value })}
                      placeholder="- atau 1 (satu) berkas"
                      className={inputClass}
                    />
                  </div>
                </div>

                <div>
                  <label className={labelClass}>Perihal / Hal</label>
                  <input
                    type="text"
                    value={doc.subject}
                    onChange={(e) => updateDoc({ subject: e.target.value })}
                    placeholder="Pokok isi surat"
                    className={inputClass}
                  />
                </div>

                <div>
                  <label className={labelClass}>Tujuan / Kepada Yth. (1 baris per elemen)</label>
                  <textarea
                    rows={4}
                    value={doc.recipientLines.join('\n')}
                    onChange={(e) =>
                      updateDoc({ recipientLines: e.target.value.split('\n') })
                    }
                    placeholder={'Yth. Bapak/Ibu Pimpinan\ndi Tempat'}
                    className={inputClass}
                  />
                </div>
              </>
            )}
          </>
        )}

        {activeTab === 'isi' && (
          <>
            <div>
              <label className={labelClass}>Salam Pembuka (Opsional)</label>
              <input
                type="text"
                value={doc.salutation}
                onChange={(e) => updateDoc({ salutation: e.target.value })}
                placeholder="Dengan hormat, (kosongkan jika tidak perlu)"
                className={inputClass}
              />
            </div>

            <div>
              <label className={labelClass}>Paragraf Pembuka</label>
              <textarea
                rows={4}
                value={doc.openingParagraph}
                onChange={(e) => updateDoc({ openingParagraph: e.target.value })}
                className={inputClass}
              />
            </div>

            {/* Detail Terstruktur */}
            <div className="border-t border-slate-100 pt-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-medium text-slate-700">
                  Blok Rincian Data (Hari/Waktu/Identitas/Poin)
                </label>
                <button
                  type="button"
                  onClick={addDetailRow}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-[#1e3a5f] bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Tambah Baris
                </button>
              </div>

              {doc.detailRows.length === 0 ? (
                <p className="text-xs text-slate-500 py-2">
                  Belum ada baris rincian. Klik &ldquo;Tambah Baris&rdquo; bila ingin menyisipkan detail waktu, tempat, atau identitas.
                </p>
              ) : (
                <div className="space-y-2">
                  {doc.detailRows.map((row) => (
                    <div key={row.id} className="flex items-start gap-2">
                      <input
                        type="text"
                        value={row.label}
                        onChange={(e) => updateDetailRow(row.id, 'label', e.target.value)}
                        placeholder="Label (mis. Hari)"
                        className="w-36 shrink-0 rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#1e3a5f] focus:outline-none"
                      />
                      <input
                        type="text"
                        value={row.value}
                        onChange={(e) => updateDetailRow(row.id, 'value', e.target.value)}
                        placeholder="Isi keterangan"
                        className="flex-1 rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#1e3a5f] focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => removeDetailRow(row.id)}
                        title="Hapus baris"
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Paragraf Isi */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-700">Paragraf Isi Lanjutan</label>
                <button
                  type="button"
                  onClick={addBodyParagraph}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-[#1e3a5f] bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Tambah Paragraf
                </button>
              </div>

              {doc.bodyParagraphs.map((para, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">Paragraf {idx + 1}</span>
                    <button
                      type="button"
                      onClick={() => removeBodyParagraph(idx)}
                      className="text-xs text-red-600 hover:underline cursor-pointer"
                    >
                      Hapus
                    </button>
                  </div>
                  <textarea
                    rows={3}
                    value={para}
                    onChange={(e) => updateBodyParagraph(idx, e.target.value)}
                    className={inputClass}
                  />
                </div>
              ))}
            </div>

            <div className="border-t border-slate-100 pt-4">
              <label className={labelClass}>Paragraf Penutup</label>
              <textarea
                rows={3}
                value={doc.closingParagraph}
                onChange={(e) => updateDoc({ closingParagraph: e.target.value })}
                className={inputClass}
              />
            </div>

            <div className="border-t border-slate-100 pt-4">
              <label className={labelClass}>Tembusan (1 baris per tujuan, opsional)</label>
              <textarea
                rows={3}
                value={doc.ccList.join('\n')}
                onChange={(e) => updateDoc({ ccList: e.target.value.split('\n') })}
                placeholder={'1. Kepala Bagian Umum;\n2. Arsip.'}
                className={inputClass}
              />
            </div>
          </>
        )}

        {activeTab === 'pengesahan' && (
          <>
            <div className="space-y-3.5">
              <div>
                <label className={labelClass}>Keterangan Jabatan / Atas Nama (Baris 1)</label>
                <textarea
                  rows={2}
                  value={doc.signerDepartment}
                  onChange={(e) => updateDoc({ signerDepartment: e.target.value })}
                  placeholder="Contoh: a.n. Kepala Dinas / PT Nusantara Karya Mandiri"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Jabatan Penandatangan (Baris 2, opsional)</label>
                <input
                  type="text"
                  value={doc.signerTitle}
                  onChange={(e) => updateDoc({ signerTitle: e.target.value })}
                  placeholder="Contoh: Direktur Utama,"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Nama Lengkap &amp; Gelar Penandatangan</label>
                <input
                  type="text"
                  value={doc.signerName}
                  onChange={(e) => updateDoc({ signerName: e.target.value })}
                  placeholder="Drs. Hendra Wijaya, M.Si."
                  className={inputClass}
                />
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className={labelClass}>Label ID</label>
                  <input
                    type="text"
                    value={doc.signerIdLabel}
                    onChange={(e) => updateDoc({ signerIdLabel: e.target.value })}
                    placeholder="NIP / NIK"
                    className={inputClass}
                  />
                </div>
                <div className="col-span-2">
                  <label className={labelClass}>Nomor Induk (NIP / NIK / NIDN)</label>
                  <input
                    type="text"
                    value={doc.signerIdValue}
                    onChange={(e) => updateDoc({ signerIdValue: e.target.value })}
                    placeholder="19740817 199903 1 004"
                    className={`${inputClass} font-mono tabular-nums`}
                  />
                </div>
              </div>
            </div>

            {/* Tanda Tangan Digital */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-700">
                  Tanda Tangan Digital
                </label>
                {doc.signatureDataUrl && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-mono tabular-nums">
                      Ukuran {doc.signatureScale}%
                    </span>
                    <input
                      type="range"
                      min={60}
                      max={140}
                      value={doc.signatureScale}
                      onChange={(e) =>
                        updateDoc({ signatureScale: Number(e.target.value) })
                      }
                      className="w-20 accent-[#1e3a5f]"
                    />
                  </div>
                )}
              </div>
              <SignaturePad
                value={doc.signatureDataUrl}
                onChange={(signatureDataUrl) => updateDoc({ signatureDataUrl })}
              />
            </div>

            {/* Stempel Instansi */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-slate-700">
                    Stempel Instansi Otomatis
                  </div>
                  <div className="text-xs text-slate-500">
                    Menambahkan cap stempel dinas di area tanda tangan
                  </div>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={doc.showStamp}
                  onClick={() => updateDoc({ showStamp: !doc.showStamp })}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${
                    doc.showStamp ? 'bg-[#1e3a5f]' : 'bg-slate-200'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-xs transition-transform ${
                      doc.showStamp ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {doc.showStamp && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className={labelClass}>Teks Lingkar Stempel</label>
                    <input
                      type="text"
                      value={doc.stampTextTop}
                      onChange={(e) => updateDoc({ stampTextTop: e.target.value })}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Teks Tengah Stempel</label>
                    <input
                      type="text"
                      value={doc.stampTextCenter}
                      onChange={(e) => updateDoc({ stampTextCenter: e.target.value })}
                      className={inputClass}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Pengaturan Kertas & Tipografi */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <div className="text-xs font-medium text-slate-700">
                Format Kertas &amp; Tipografi Cetak
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Ukuran Kertas</label>
                  <select
                    value={doc.paperSize}
                    onChange={(e) => updateDoc({ paperSize: e.target.value as PaperSize })}
                    className={inputClass}
                  >
                    <option value="A4">A4 (210 × 297 mm)</option>
                    <option value="F4">F4 / Folio (215 × 330 mm)</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>Margin Kertas</label>
                  <select
                    value={doc.marginPreset}
                    onChange={(e) =>
                      updateDoc({ marginPreset: e.target.value as MarginPreset })
                    }
                    className={inputClass}
                  >
                    <option value="standard">Standar Dinas</option>
                    <option value="compact">Rapat (Muat Lebih Banyak)</option>
                    <option value="wide">Lebar (Eksekutif)</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>Jenis Huruf Surat</label>
                  <select
                    value={doc.fontFamily}
                    onChange={(e) => updateDoc({ fontFamily: e.target.value as LetterFont })}
                    className={inputClass}
                  >
                    <option value="times">Times New Roman (Dinas)</option>
                    <option value="arial">Arial / Sans-Serif (Korporat)</option>
                    <option value="georgia">Georgia Serif (Formal Klasik)</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>Ukuran Huruf</label>
                  <select
                    value={doc.fontSizePt}
                    onChange={(e) =>
                      updateDoc({ fontSizePt: Number(e.target.value) as 10 | 11 | 12 })
                    }
                    className={inputClass}
                  >
                    <option value={10}>10 pt</option>
                    <option value={11}>11 pt (Rekomendasi)</option>
                    <option value={12}>12 pt</option>
                  </select>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
