import html2canvas from 'html2canvas-pro';
import { jsPDF } from 'jspdf';
import { LetterDocument } from '../types/letter';
import { PAPER_DIMENSIONS } from '../components/LetterPreview';

function sanitizeFileName(raw: string): string {
  return raw
    .replace(/[\\/:*?"<>|]/g, '-')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 80) || 'Surat';
}

function waitForNextPaint(): Promise<void> {
  return new Promise((resolve) => {
    requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
  });
}

export async function exportLetterToPdf(doc: LetterDocument): Promise<string> {
  const sourceElement = document.getElementById('printable-letter-sheet');
  if (!sourceElement) {
    throw new Error('Elemen pratinjau surat tidak ditemukan. Buka pratinjau surat lalu coba lagi.');
  }

  const dimensions = PAPER_DIMENSIONS[doc.paperSize] ?? PAPER_DIMENSIONS.A4;
  const { widthMm, heightMm } = dimensions;
  const offscreenHost = document.createElement('div');
  Object.assign(offscreenHost.style, {
    position: 'fixed',
    left: '0',
    top: '0',
    width: `${widthMm}mm`,
    backgroundColor: '#ffffff',
    opacity: '0',
    pointerEvents: 'none',
    zIndex: '-1',
    overflow: 'visible',
  });

  const clonedSheet = sourceElement.cloneNode(true) as HTMLElement;
  Object.assign(clonedSheet.style, {
    width: `${widthMm}mm`,
    minHeight: `${heightMm}mm`,
    height: 'auto',
    transform: 'none',
    transformOrigin: 'top left',
    boxShadow: 'none',
    margin: '0',
    boxSizing: 'border-box',
  });
  clonedSheet.querySelectorAll('.page-break-guide, .no-print').forEach((node) => node.remove());

  offscreenHost.appendChild(clonedSheet);
  document.body.appendChild(offscreenHost);

  try {
    if (document.fonts?.ready) await document.fonts.ready;
    const images = Array.from(clonedSheet.querySelectorAll('img'));
    await Promise.all(
      images.map(async (img) => {
        if (img.complete) return;
        await new Promise<void>((resolve) => {
          img.addEventListener('load', () => resolve(), { once: true });
          img.addEventListener('error', () => resolve(), { once: true });
        });
      })
    );
    await waitForNextPaint();

    const canvas = await html2canvas(clonedSheet, {
      scale: 2,
      useCORS: true,
      allowTaint: false,
      backgroundColor: '#ffffff',
      logging: false,
      imageTimeout: 15000,
      windowWidth: Math.max(document.documentElement.clientWidth, clonedSheet.scrollWidth),
      onclone: (_clonedDocument, clonedElement) => {
        (clonedElement as HTMLElement).style.transform = 'none';
      },
    });

    if (!canvas.width || !canvas.height) {
      throw new Error('Pratinjau surat kosong sehingga PDF tidak dapat dibuat.');
    }

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [widthMm, heightMm],
      compress: true,
    });

    // Slice the captured sheet into page-sized canvases. This avoids placing one
    // oversized image on every page and reduces clipping/memory issues for long letters.
    const pxPerMm = canvas.width / widthMm;
    const pageHeightPx = Math.max(1, Math.round(heightMm * pxPerMm));
    const pageCount = Math.ceil(canvas.height / pageHeightPx);
    if (pageCount > 50) {
      throw new Error('Surat terlalu panjang untuk diekspor sekaligus (lebih dari 50 halaman).');
    }

    for (let pageIndex = 0; pageIndex < pageCount; pageIndex += 1) {
      const sourceY = pageIndex * pageHeightPx;
      const sliceHeight = Math.min(pageHeightPx, canvas.height - sourceY);
      if (sliceHeight <= 0) continue;

      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = canvas.width;
      pageCanvas.height = sliceHeight;
      const context = pageCanvas.getContext('2d');
      if (!context) throw new Error('Gagal menyiapkan halaman PDF.');
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
      context.drawImage(canvas, 0, sourceY, canvas.width, sliceHeight, 0, 0, canvas.width, sliceHeight);

      if (pageIndex > 0) pdf.addPage([widthMm, heightMm], 'portrait');
      const renderedHeightMm = (sliceHeight * widthMm) / canvas.width;
      pdf.addImage(pageCanvas.toDataURL('image/jpeg', 0.96), 'JPEG', 0, 0, widthMm, renderedHeightMm, undefined, 'FAST');
      pageCanvas.width = 0;
      pageCanvas.height = 0;
    }

    const titlePart = doc.formatStyle === 'decree' ? doc.decreeTitle : doc.templateName;
    const numberPart = doc.letterNumber || 'Draft';
    const fileName = `${sanitizeFileName(titlePart)}_${sanitizeFileName(numberPart)}.pdf`;
    pdf.save(fileName);
    return fileName;
  } finally {
    offscreenHost.remove();
  }
}
