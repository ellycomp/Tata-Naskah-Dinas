export type LetterCategory = 'Pemerintahan' | 'Perusahaan' | 'Pendidikan' | 'Organisasi';

export type LetterFormatStyle = 'correspondence' | 'decree';

export type LetterheadLayout = 'left-center' | 'left-left' | 'dual-center';

export type DividerStyle = 'double-official' | 'single-bold' | 'accent-line';

export type BuiltInLogoId = 'shield' | 'corporate' | 'academic' | 'organization' | 'none';

export type PaperSize = 'A4' | 'F4';

export type LetterFont = 'times' | 'arial' | 'georgia';

export type MarginPreset = 'standard' | 'compact' | 'wide';

export type ContactLastLineMode = 'inline' | 'website-last' | 'email-last';

export interface LetterheadConfig {
  id: string;
  profileName: string;
  category: LetterCategory;
  parentOrg: string;
  orgName: string;
  subUnit: string;
  address: string;
  contactLine: string;
  websiteLine?: string;
  websiteEmailLine: string;
  websiteOnLastLine?: boolean;
  contactLastLineMode?: ContactLastLineMode;
  layout: LetterheadLayout;
  dividerStyle: DividerStyle;
  accentColor: string;
  builtInLogo: BuiltInLogoId;
  rightBuiltInLogo: BuiltInLogoId;
  customLogoDataUrl: string | null;
  leftLogoSize: number;
  showRightLogo: boolean;
  rightLogoDataUrl: string | null;
  rightLogoSize: number;
}

export interface LetterDetailRow {
  id: string;
  label: string;
  value: string;
}

export interface LetterDocument {
  id: string;
  templateId: string;
  templateName: string;
  category: LetterCategory;
  formatStyle: LetterFormatStyle;
  decreeTitle: string;
  letterhead: LetterheadConfig;
  letterNumber: string;
  attachment: string;
  urgency: string;
  subject: string;
  city: string;
  dateString: string;
  recipientLines: string[];
  salutation: string;
  openingParagraph: string;
  detailRows: LetterDetailRow[];
  bodyParagraphs: string[];
  closingParagraph: string;
  signerDepartment: string;
  signerTitle: string;
  signerName: string;
  signerIdLabel: string;
  signerIdValue: string;
  signatureDataUrl: string | null;
  signatureScale: number;
  showStamp: boolean;
  stampTextTop: string;
  stampTextCenter: string;
  stampColor: string;
  ccList: string[];
  paperSize: PaperSize;
  fontFamily: LetterFont;
  fontSizePt: 10 | 11 | 12;
  marginPreset: MarginPreset;
  updatedAt: string;
}

export interface LetterTemplate {
  id: string;
  name: string;
  category: LetterCategory;
  formatStyle: LetterFormatStyle;
  description: string;
  defaultLetterheadId: string;
  buildDocument: (letterhead: LetterheadConfig) => LetterDocument;
}
